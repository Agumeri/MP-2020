/**
 * @file move.cpp
 * @author DECSAI
 * @note To be implemented by students
 */
#include <string>
#include <iostream>
#include <fstream>
#include "player.h"
#include "language.h"
#include "move.h"
using namespace std;

Move::Move()  {
    row = 0;
    column = 0;
    ishorizontal = true;
    letters = "";
    score = 0;
}

void Move::set(int &r, int &c, char &h, const std::string &l) {
    setRow(r);
    setCol(c);
    setHorizontal(h);
    setLetters(l);
}

void Move::setRow(int &r) {
    row = r;
}

void Move::setCol(int &c){
    column = c;
}

void Move::setHorizontal(char &h){
    if(h == 'H'){
        ishorizontal = true;
    }else if(h == 'V'){
        ishorizontal = false;
    }
}

void Move::setLetters(const std::string &l) {
    if(l != "@")
        letters = normalizeWord(l);
    else
        letters = l;
}

int Move::findScore(const Language &l){
    int aux = 0;
    for(int i=0; i<letters.size(); i++){
        aux += l.getScore(letters[i]);
    }
    //Establecemos una vez calculada la puntuación a su atributo correspondiente
    this->setScore(aux);
}

void Move::setScore(int &s){
    this->score = s;
}

int Move::getScore() const{
    return this->score;
}

int Move::getRow() const{
    return this->row;
}

int Move::getCol() const{
    return this->column;
}

bool Move::isHorizontal() const{
    return this->ishorizontal;
}

std::string Move::getLetters() const{
    return this->letters;
}

void Move::print(std::ostream &os) const{
    os << "READ: ";
    
    if(isHorizontal())
        os << "H ";
    else
        os << "V ";
    
    os << row << " " << column << " " << letters << " ";
    
    
}

void Move::read(std::istream &is) {
    int n_r, n_c;
    char horz;
    std::string palabra;
    //@warging reading
    is >> horz;
    is >> n_r;
    is >> n_c;
    is >> palabra;

    Move m;
    m.set(n_r, n_c, horz, palabra);
    
    *this = m;

}